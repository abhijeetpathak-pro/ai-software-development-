import type { Metadata } from 'next';
import PageHero from '@/components/PageHero';
import CtaBand from '@/components/CtaBand';

export const metadata: Metadata = {
  title: 'Our Team',
  description: 'Meet the leadership and engineering team behind WitQualis Technologies.'
};

const team = [
  { name: 'Aslam Khan', role: 'Founder & CEO', bio: 'Leads client strategy and engagement design. Background in enterprise software delivery.' },
  { name: 'Akhil Sharma', role: 'Co-Founder & Head of Engineering', bio: 'Owns technical vetting and architecture reviews across every stack we staff for.' },
  { name: 'Priya Nair', role: 'Lead, AI & Data Engineering', bio: 'Runs the AI practice \u2014 from feasibility audits to production model deployment.' },
  { name: 'Rahul Verma', role: 'Lead, Frontend Engineering', bio: 'Sets frontend standards across React, Vue, and Angular engagements.' },
  { name: 'Sneha Iyer', role: 'Lead, Mobile Engineering', bio: 'Oversees iOS, Android, and cross-platform delivery quality.' },
  { name: 'Karan Mehta', role: 'Head of Talent', bio: 'Runs the technical screening and trial-matching process for every placement.' }
];

export default function OurTeamPage() {
  return (
    <>
      <PageHero
        eyebrow="Our Team"
        title="The people who vet every developer before you meet them"
        description="A small, senior team \u2014 each engagement is reviewed by someone who's shipped in that stack, not just recruited for it."
      />
      <section className="py-20">
        <div className="mx-auto grid max-w-6xl gap-6 px-5 sm:grid-cols-2 lg:grid-cols-3 lg:px-8">
          {team.map((m) => (
            <div key={m.name} className="rounded-2xl border border-ink/10 bg-white p-7">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-ink font-display text-lg font-bold text-teal-light">
                {m.name.split(' ').map((n) => n[0]).join('')}
              </div>
              <h3 className="mt-4 font-display text-lg font-bold">{m.name}</h3>
              <p className="text-xs font-semibold uppercase tracking-wide text-teal-dark">{m.role}</p>
              <p className="mt-2 text-sm text-ink/60">{m.bio}</p>
            </div>
          ))}
        </div>
      </section>
      <CtaBand heading="Want to talk to the team directly?" />
    </>
  );
}
